"""Build editable PPTX and a self-contained Guizang magazine HTML deck."""
from __future__ import annotations

import base64
import html
import json
import math
import re
import zipfile
from pathlib import Path

from opencc import OpenCC
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE, MSO_CONNECTOR
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.xmlchemy import OxmlElement
from pptx.util import Inches, Pt

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "guizang-source"
OUT = ROOT / "deliverables"
WIDTH, HEIGHT = 13.333333, 7.5
PAPER, INK, ACCENT = "EEDFC7", "2A1E13", "9B5A2E"
TITLE_FONT, BODY_FONT = "PMingLiU", "Microsoft JhengHei"
HK_CONVERTER = OpenCC("s2t")
CANTONESE_REPLACEMENTS = (
    ("演講者視圖", "講者畫面"),
    ("演講模式", "講者模式"),
    ("觀眾屏", "觀眾畫面"),
    ("觀眾頁面", "觀眾畫面"),
    ("觀眾窗口", "觀眾視窗"),
    ("演示結束", "簡報完結"),
    ("當前頁預覽", "目前投影片預覽"),
    ("當前頁", "目前投影片"),
    ("選擇頁面", "選擇投影片"),
    ("宮格選頁", "投影片總覽"),
    ("激光筆", "雷射筆"),
    ("清除標記", "清除記號"),
    ("本頁演講備註", "呢頁講稿"),
    ("縮小備註字號", "縮細講稿字體"),
    ("放大備註字號", "放大講稿字體"),
    ("重新打開觀眾畫面", "重新開啟觀眾畫面"),
    ("臨時遮擋", "暫時遮住"),
    ("根據屏幕寬度", "因應螢幕闊度"),
    ("頁面優先", "投影片優先"),
    ("備註優先", "講稿優先"),
    ("均衡", "平衡"),
    ("黑屏", "黑畫面"),
    ("白屏", "白畫面"),
    ("查看快捷鍵", "睇吓快捷鍵"),
    ("瀏覽器阻止了觀眾視窗", "瀏覽器封鎖咗觀眾視窗"),
    ("未檢測到彈窗攔截", "未偵測到彈出視窗攔截"),
    ("尚未全屏，可在演講前進入", "未進入全螢幕；可以喺講者模式開始前開啟"),
    ("窗口不可見", "視窗未顯示"),
    ("觀眾屏已暫停", "觀眾畫面已暫停"),
    ("演前檢查", "簡報前檢查"),
    ("退出", "離開"),
    ("激光", "雷射"),
    ("計劃", "安排"),
    ("已進行", "已用"),
    ("默認", "預設"),
    ("需要時手動開啟", "有需要先手動開啟"),
    ("全局間隔", "整體間隔"),
    ("投影儀", "投影機"),
    ("線纜", "線材"),
    ("演示者佈局", "講者版面"),
    ("演講者佈局", "講者版面"),
    ("屏幕", "螢幕"),
    ("備註", "講稿"),
    ("設置", "設定"),
    ("演示設置", "簡報設定"),
    ("已保存", "已儲存"),
    ("保存中", "儲存中"),
    ("保存", "儲存"),
    ("演示已結束", "簡報已結束"),
    ("演示", "簡報"),
    ("自動翻頁", "自動換頁"),
    ("幻燈片", "投影片"),
    ("頁面", "投影片"),
    ("當前頁", "目前頁"),
    ("本頁目的", "呢頁重點"),
    ("頁面目的", "呢頁重點"),
    ("草稿（備註）", "講稿內容"),
    ("備註", "講稿"),
    ("標題", "標題"),
    ("宮格選頁", "總覽選頁"),
    ("宮格", "總覽"),
    ("激光筆", "雷射指示器"),
    ("設置", "設定"),
    ("保存中", "儲存中"),
    ("已保存", "已儲存"),
    ("保存", "儲存"),
    ("排練", "試講"),
    ("分鐘", "分鐘"),
    ("自動翻頁", "自動換頁"),
    ("開始計時", "開始計時"),
    ("繼續計時", "繼續計時"),
    ("重置計時", "重新計時"),
    ("重新開始", "重新開始"),
    ("上一頁", "上一頁"),
    ("下一頁", "下一頁"),
    ("首頁", "封面"),
    ("尾頁", "最後一頁"),
    ("演示設置", "簡報設定"),
    ("演示已結束", "簡報已結束"),
    ("演示结束", "簡報完結"),
    ("演示", "簡報"),
    ("沒有", "冇"),
    ("未連接", "未連線"),
    ("連接", "連線"),
    ("剩餘", "餘下"),
    ("距本頁計畫", "距離本頁安排"),
    ("計畫", "安排"),
    ("預計", "預計"),
    ("全屏", "全螢幕"),
    ("弹窗", "彈出視窗"),
    ("窗口", "視窗"),
    ("未检测到", "未偵測到"),
    ("观众", "觀眾"),
    ("不如", "__HK_NOT_RATHER__"),
    ("不過", "__HK_NOT_BUT__"),
    ("而不是", "而唔係"),
    ("並不是", "並唔係"),
    ("不只是", "唔止係"),
    ("不單是", "唔單止係"),
    ("不需要", "唔使"),
    ("不必", "唔使"),
    ("不急着", "唔使急住"),
    ("不急著", "唔使急住"),
    ("不能", "唔可以"),
    ("不可", "唔好"),
    ("不要", "唔好"),
    ("不會", "唔會"),
    ("不想", "唔想"),
    ("不是", "唔係"),
    ("並非", "唔係"),
    ("不", "唔"),
    ("是否", "係咪"),
    ("是", "係"),
    ("為甚麼", "點解"),
    ("為什麼", "點解"),
    ("甚麼", "乜嘢"),
    ("什麼", "乜嘢"),
    ("怎樣", "點樣"),
    ("如何", "點樣"),
    ("我們的", "我哋嘅"),
    ("我們", "我哋"),
    ("你們", "你哋"),
    ("他們", "佢哋"),
    ("她們", "佢哋"),
    ("這次", "今次"),
    ("這些", "呢啲"),
    ("這個", "呢個"),
    ("這頁", "呢頁"),
    ("這一", "呢一"),
    ("這", "呢"),
    ("那位", "嗰位"),
    ("那個", "嗰個"),
    ("那一", "嗰一"),
    ("那", "嗰"),
    ("今天", "今日"),
    ("平常", "平時"),
    ("不同", "唔同"),
    ("也可以", "都可以"),
    ("也是", "都係"),
    ("也", "都"),
    ("而是", "而係"),
    ("就是", "就係"),
    ("參與", "參加"),
    ("巧克力", "朱古力"),
    ("拿", "攞"),
    ("本頁目的", "呢頁重點"),
    ("本頁", "呢頁"),
    ("在慶祝", "喺慶祝"),
    ("在各種文化潮流中", "面對唔同文化潮流"),
    ("在同一張", "放喺同一張"),
    ("在北美", "去到北美"),
    ("現在", "而家"),
    ("接下來", "跟住"),
    ("逐步", "慢慢"),
    ("逐漸", "慢慢"),
    ("看看", "睇吓"),
    ("看清", "睇清楚"),
    ("看到", "睇到"),
    ("看成", "睇成"),
    ("思考", "諗"),
    ("考慮", "諗"),
    ("想一想", "諗吓"),
    ("想想", "諗吓"),
    ("了解", "認識"),
    ("記得", "記住"),
    ("說話", "講嘢"),
    ("說出", "講出"),
    ("說明", "講清楚"),
    ("說法", "講法"),
    ("說", "講"),
    ("作出", "做出"),
    ("進行", "做"),
    ("詢問", "問"),
    ("與", "同"),
    ("以及", "同埋"),
    ("還是", "定係"),
    ("但是", "但係"),
    ("因此", "所以"),
    ("讓我們", "等我哋"),
    ("讓大家", "等大家"),
    ("讓每個人", "等每個人"),
    ("讓一位朋友感到被接納", "令朋友感受到被接納"),
    ("讓一位朋友", "令朋友"),
    ("讓", "等"),
    ("由於", "因為"),
    ("若", "如果"),
    ("的確", "確實"),
    ("目的", "__HK_MU_DI__"),
    ("自己的", "自己嘅"),
    ("朋友的", "朋友嘅"),
    ("大家的", "大家嘅"),
    ("對方的", "對方嘅"),
    ("我們的", "我哋嘅"),
    ("你們的", "你哋嘅"),
    ("我們的", "我哋嘅"),
    ("你的", "你嘅"),
    ("我的", "我嘅"),
    ("的", "嘅"),
    ("__HK_MU_DI__", "目的"),
    ("不孤單", "唔係一個人"),
    ("幫忙", "幫手"),
    ("讀完", "讀完"),
    ("逐頁計畫", "每頁安排"),
    ("預留", "留返"),
    ("約在", "大約係"),
    ("作停頓", "停一停"),
    ("標準答案", "標準答案"),
    ("安全、輕鬆", "安心又輕鬆"),
    ("正面隊名", "聽落正面嘅隊名"),
    ("結束時", "完結嗰陣"),
    ("例如", "例如"),
    ("周圍", "周圍"),
    ("說明", "講清楚"),
    ("表達", "講出"),
    ("作選擇", "揀"),
    ("為了", "為咗"),
    ("有了", "有咗"),
    ("還", "仲"),
    ("找", "搵"),
    ("仍然", "仲"),
    ("仍有", "仲有"),
    ("吓", "下"),
)
HISTORY = "https://www.history.com/articles/history-of-halloween"
DESIGN = "https://github.com/op7418/guizang-ppt-skill"


def cantonese(text, verbatim=False):
    if verbatim:
        return text
    text = HK_CONVERTER.convert(text).replace("禰", "祢").replace("衆", "眾")
    for source, target in CANTONESE_REPLACEMENTS:
        text = text.replace(source, target)
    text = text.replace("__HK_NOT_RATHER__", "不如").replace("__HK_NOT_BUT__", "不過")
    return text


def localize(value, key=None):
    if isinstance(value, str):
        return cantonese(value, verbatim=key == "quote")
    if isinstance(value, list):
        return [localize(item) for item in value]
    if isinstance(value, tuple):
        return tuple(localize(item) for item in value)
    if isinstance(value, dict):
        return {name: localize(item, name) for name, item in value.items()}
    return value


def page(id, title, section, minutes, theme, kind, purpose, talk, transition, **extra):
    return localize(dict(id=id, title=title, section=section, minutes=minutes,
                         theme=theme, kind=kind, purpose=purpose, talk=talk,
                         transition=transition, **extra))


PAGES = [
    page("choose-light", "選擇光明，活出喜樂", "破冰遊戲｜00–10 分鐘", .5,
         "hero dark", "cover", "以喜樂、尊重和信仰分辨建立聚會氣氛。",
         ["歡迎大家。今日唔係要取笑慶祝萬聖節嘅人，而係一齊諗清楚自己嘅選擇。",
          "可以分享，也可以先聆聽；不需要透露令你不舒服的經歷。",
          "我們會玩遊戲、了解文化、討論同儕壓力，最後以禱告和光明派對回應。"],
         "先看看這一小時的路線。"),
    page("meeting-roadmap", "一小時，一起走向光", "破冰遊戲｜00–10 分鐘", .5,
         "light", "agenda", "讓青少年知道五個環節及各自的時間。",
         ["按時間介紹五個環節，不逐字朗讀表格。",
          "活動共 60 分鐘；逐頁計畫 54 分鐘，預留 6 分鐘作停頓、換組和交流。",
          "小組討論不設標準答案；歡迎真實說出同學邀請時的困難。"],
         "用三道真假題熱身，看看我們知道多少。"),
    page("game-rules", "真假萬聖節大挑戰", "破冰遊戲｜00–10 分鐘", 1,
         "dark", "rules", "講清楚分隊、作答和計分，建立安全、輕鬆的參與方式。",
         ["分成「光明隊」與「晨光隊」，兩個隊名都正面，不把任何一組叫黑暗隊。",
          "各隊可用真／假卡、手勢或口頭作答；讀完題目後口數 5 秒。",
          "答對得 1 分；先鎖定答案才翻下一頁揭曉。不嘲笑答錯的人。"],
         "第一題：討糖果最初就是為了拿巧克力嗎？"),
    page("quiz-treat", "討糖果，一開始就是為了拿巧克力？",
         "破冰遊戲｜00–10 分鐘", .75, "hero light", "quiz",
         "讓兩隊先作答，再揭曉，避免答案提前出現。",
         ["只讀題目，不透露答案頁的內容。",
          "請兩隊商量，讀完後口數 5、4、3、2、1。",
          "確認兩隊已亮出真／假卡，再翻頁。"],
         "看看今天的糖果習俗，有哪些歷史前身。",
         question="「Trick or Treat」一開始，\n就是為了拿巧克力？", quiz_number="01"),
    page("answer-treat", "假：糖果不是唯一的起點",
         "破冰遊戲｜00–10 分鐘", 1.5, "light", "answer",
         "用較審慎的說法交代 souling、guising 與現代討糖果的關係。",
         ["宣布答案：假。討糖果並非最初為了拿巧克力。",
          "相關前身包括 souling：以為亡者祈禱換取食物或「靈魂餅」；以及 guising：裝扮後表演換取食物或小禮物。",
          "習俗經不同地區和年代演變，不能把現代討糖果簡化為一條確定的「古凱爾特驅鬼」直線。"],
         "接下來看南瓜燈：主角一直都是南瓜嗎？",
         answer="假", heading="不只巧克力，\n也不只一種起源。",
         body="相關前身包括祈禱換取「靈魂餅」，\n以及裝扮表演換取食物或小禮物。\n現代討糖果由多種習俗逐步演變。",
         source_label="歷史參考：HISTORY｜History of Halloween"),
    page("quiz-lantern",     "南瓜燈，最早係用南瓜做嘅？",
         "破冰遊戲｜00–10 分鐘", .75, "dark", "quiz",
         "以熟悉的節日符號引起好奇。",
         ["讀題：「Jack-o'-lantern 最早就是用南瓜做的？」",
          "讀完後口數 5 秒，提醒隊員一起作答。",
          "鎖定答案後才翻頁；可以先請一位隊員說說理由。"],
         "答案藏在愛爾蘭的蔬菜裡。",
         question="Jack-o'-lantern，\n最早就是用南瓜做的？", quiz_number="02"),
    page("answer-lantern", "假：早期常用蕪菁",
         "破冰遊戲｜00–10 分鐘", 1.5, "light", "answer",
         "讓青少年看見民俗隨地區和材料而改變。",
         ["宣布答案：假。愛爾蘭等地早期常用蕪菁或其他根莖蔬菜雕刻燈籠。",
          "移民到北美後，南瓜因較常見、較易雕刻而廣泛使用。",
          "符號和材料會變；今天我們也可以主動選擇傳遞希望的創意，而不是用恐怖嚇人。"],
         "最後一題，回到節日更早的背景。",
         answer="假", heading="先有蕪菁燈，\n後有南瓜燈。",
         body="愛爾蘭等地早期常雕刻蕪菁等根莖。\n移民到北美後，南瓜逐漸成為常見材料。\n同一個符號，也會隨文化而改變。",
         source_label="民俗重點：早期根莖燈籠 → 北美南瓜燈"),
    page("quiz-samhain",     "萬聖節嘅歷史背景，包括薩溫節？",
         "破冰遊戲｜00–10 分鐘", .75, "hero dark", "quiz",
         "把遊戲自然連接到歷史講解，避免混淆薩溫節與冬至。",
         ["讀題：「萬聖節的歷史背景，包括古凱爾特人的薩溫節？」",
          "口數 5 秒；不把問題改成「只有單一起源」，以免造成誤導。",
          "先鎖定答案，再揭曉；順便宣布兩隊分數。"],
         "正確答案，也提醒我們一個常見的日期誤會。",
         question="萬聖節嘅歷史背景，\n包括古凱爾特人嘅薩溫節？", quiz_number="03"),
    page("answer-samhain", "真：薩溫節是重要背景之一",
         "破冰遊戲｜00–10 分鐘", 1.75, "light", "answer",
         "修正冬至前夕的誤說，建立多來源歷史框架。",
         ["宣布答案：真，薩溫節是萬聖節的重要歷史背景之一。",
          "薩溫節與收穫季結束、進入冬季有關，約在 10 月 31 日至 11 月 1 日；不是 12 月的冬至前夕。",
          "萬聖節也有基督教節期與後來民俗的影響。古人的亡靈信念是歷史記述，不是今天要證實的事實。"],
         "知道節日從哪裡來後，我們還要問：今天怎樣選擇？",
         answer="真", heading="收穫季結束，\n冬季將開始。",
         body="薩溫節（Samhain）是重要歷史背景之一。\n時間約在 10 月 31 日至 11 月 1 日。\n不是冬至前夕；也不是萬聖節的唯一來源。",
         source_label="日期辨識：入冬節期 ≠ 12 月冬至"),
    page("culture-and-choice", "知道由來，更要想清楚選擇",
         "專題講解｜10–25 分鐘", .5, "hero light", "hook",
         "由文化知識轉向生活和信仰分辨。",
         ["大家平時諗起萬聖節，可能就係扮靚、食糖果、同朋友去 Party。",
          "好玩以外，我哋都可以問：呢個活動喺慶祝乜嘢？會點樣影響我同身邊嘅人？",
          "今日一齊認識背景，再用信仰諗清楚點樣選擇，同時尊重其他人。"],
         "先把三段歷史放在同一張時間線上。"),
    page("history-timeline", "一個節日，幾層歷史",
         "專題講解｜10–25 分鐘", 2.5, "light", "timeline",
         "區分古代民俗、基督教節期名稱和近代娛樂化。",
         ["第一層：古凱爾特的薩溫節，與收穫、入冬、篝火及當時的亡靈信念有關。",
          "第二層：西方教會的諸聖節是 11 月 1 日；前一晚稱 All Hallows' Eve，名稱後來成為 Halloween。",
          "第三層：民俗和移民文化延續變化，逐步形成裝扮、討糖果及商業派對。",
          "歷史關係有不同解讀；避免把所有服裝、糖果或參與者都說成敬拜鬼魂。"],
         "歷史背景、今天的活動和我的信仰，是三件需要分開的事。"),
    page("separate-three-questions", "別把三件事混為一談",
         "專題講解｜10–25 分鐘", 1, "dark", "distinction",
         "說明基督徒並非一概不慶祝，清楚交代本次聚會立場。",
         ["基督徒及不同教會對萬聖節並非完全一致：有人不參與，有人記念諸聖節，也有人參加非恐怖的社區活動。",
          "本次聚會採取不參與招魂、占卜及恐怖主題活動，改以光明派對回應的方向。",
          "我們看實際活動內容、信仰和良心，不用標籤別人；若有疑問，可與家長或導師商量。"],
         "接下來用三段經文，想想自己的身份、分辨和勇氣。"),
    page("faith-light", "我們追求光，活出生命",
         "專題講解｜10–25 分鐘", 2.5, "hero dark", "faith",
         "以耶穌是世界的光建立正面的信仰身份。",
         ["邀請大家讀約翰福音 8:12。耶穌帶來的是生命的光，不只是叫我們避開某個節日。",
          "我們不是因為膽小才作出選擇；我們希望把愛、希望和生命帶給身邊的人。",
          "不把同學叫作黑暗的人，也不把喜歡裝扮的人看成壞人；我們分辨活動，而不是羞辱人。",
          "問：今天有哪些行動，可以讓一位朋友感到被接納？"],
         "有了身份，還需要學會停一停、諗一諗。",
         principle="01｜身份", quote="「我是世界的光。跟從我的，\n就不在黑暗裏走，\n必要得着生命的光。」",
         reference="約翰福音 8:12",
         applications=[("選擇傳遞", "希望、生命、愛"), ("不以恐怖作招徠", "不以標籤傷害別人")]),
    page("faith-discern", "停一停，諗一諗",
         "專題講解｜10–25 分鐘", 2.5, "light", "faith",
         "把羅馬書 12:2 化為青少年可用的分辨問題。",
         ["讀羅馬書 12:2。心意更新唔係盲目同人唱反調，而係察驗乜嘢合乎神嘅心意。",
          "流行不等於有益；同樣，一個活動的名字也不能代替對內容的了解。",
          "問：活動是否涉及招魂、占卜、刻意驚嚇或不安全行為？我是否真心願意，還是怕被排斥？",
          "可以詢問詳情、拒絕某些內容，或提出其他聚會方式。"],
         "當別人都去，而我想說不，需要哪一種勇氣？",
         principle="02｜分辨", quote="「不要效法這個世界，\n只要心意更新而變化，\n叫你們察驗何為神的善良、\n純全、可喜悅的旨意。」",
         reference="羅馬書 12:2",
         applications=[("看清內容", "這活動是否合宜、安全？"), ("看清動機", "我是願意，還是怕被排斥？")]),
    page("faith-courage", "剛強、仁愛、謹守",
         "專題講解｜10–25 分鐘", 2.5, "dark", "faith",
         "用提摩太後書 1:7 鼓勵有勇氣、有愛心、有自制的回應。",
         ["讀提摩太後書 1:7。神所賜的，不是膽怯的心。",
          "剛強：可以表明自己的界線；仁愛：語氣溫柔，不批評朋友；謹守：照顧安全與身心。",
          "覺得驚唔代表信心不足；可以搵信任嘅大人傾吓，唔使硬撐。",
          "我哋唔需要靠嚇人去證明勇敢，亦唔使靠嘲笑別人去證明自己啱。"],
         "把三個角度，變成一次具體的生活選擇。",
         principle="03｜勇氣", quote="「因為神賜給我們，\n不是膽怯的心，\n乃是剛強、仁愛、謹守的心。」",
         reference="提摩太後書 1:7",
         applications=[("有勇氣", "溫柔表明自己的界線"), ("有愛心、有自制", "尊重朋友，也照顧安全")]),
    page("choice-filter", "一個邀請，三個分辨",
         "專題講解｜10–25 分鐘", 2, "hero light", "filter",
         "示範不憑節日名稱判斷、而是查看內容與提出替代方案。",
         ["遇到派對邀請，先問清楚內容，不急着答應或責備對方。",
          "若有招魂、占卜、恐怖驚嚇或令你不安的內容，可以拒絕並說明自己的界線。",
          "本次聚會選擇光明派對：用點心、鼓勵和祝福，保留友誼與喜樂。",
          "尊重不同教會和家庭的規範；有疑問時，與家長、導師一起分辨。"],
         "現在交給小組，聽聽你們真實的想法。"),
    page("group-agreement", "真實說，也好好聽",
         "小組討論｜25–40 分鐘", 1, "dark", "group",
         "建立 4–6 人討論的安全規則及時間安排。",
         ["每組 4–6 人，由一位導師引導；請大家圍坐並找一位自願分享者。",
          "可以選擇先聆聽，不追問私人經歷；不嘲笑、不打斷，不把別組的分享當笑話。",
          "下一頁三題共討論約 11 分鐘；最後用約 1.5 分鐘練習一句回應。",
          "若出現安全或求助訊息，導師需依教會的兒少保護程序處理，不承諾絕對保密。"],
         "三個問題，從同學的邀請聊到我們的行動。"),
    page("discussion-cards", "你會怎樣選擇？",
         "小組討論｜25–40 分鐘", 11, "light", "discussion",
         "讓青少年表達同儕壓力、文化觀察和替代活動的想法。",
         ["第一題約 4 分鐘：朋友邀請你參加萬聖節派對或扮鬼活動，你最擔心甚麼？你會怎樣回應？",
          "第二題約 3 分鐘：商家如何把恐怖包裝成娛樂？哪些內容有趣，哪些讓你不舒服？不要假定每個人想法相同。",
          "第三題約 4 分鐘：若不討糖果或扮鬼，可以用甚麼有意義又好玩的方式度過這一天？",
          "讓每人有機會說話；導師多聽、少講，不急着給標準答案。"],
         "試着把想法縮成一句，讓朋友聽得懂。"),
    page("practice-reply", "有界線，也有友誼",
         "小組討論｜25–40 分鐘", 1.5, "hero dark", "reply",
         "提供不羞辱朋友、又能清楚拒絕的語句，讓青少年練習。",
         ["邀請兩人一組，一人扮邀請的朋友，一人練習回應；再交換角色。",
          "示範：「多謝你邀請我！我唔參加扮鬼或招魂活動，不過我想同你一齊玩。不如來光明派對？」",
          "可以按自己的說話方式修改；重點是感謝、界線、替代方案。",
          "若朋友持續施壓或嘲笑，不必爭辯；可以退出對話並找導師或家長幫忙。"],
         "我們不只作出選擇，也一起把需要帶到神面前。"),
    page("response-light", "不是少一點樂趣，是多一點光",
         "回應與禱告｜40–50 分鐘", 1, "hero light", "response",
         "以生命、和平和祝福總結，不以恐懼或敵意呼召。",
         ["今天不是要剝奪大家的樂趣，而是學習選擇成為點亮光芒的人。",
          "我們可以不參與不合信仰或良心的內容，同時保留對朋友的愛和尊重。",
          "當文化強調恐怖時，我們可以主動傳遞生命、和平與喜樂。"],
         "三段經文，帶走三個提醒。"),
    page("verses-takeaway", "帶走三句提醒",
         "回應與禱告｜40–50 分鐘", 2, "dark", "summary",
         "重溫經文主題，讓青少年選一項今天要實踐的提醒。",
         ["這頁是經文主題摘要，不是逐字引文；完整引文在前面的經文頁。",
          "約翰福音 8:12：跟從耶穌，帶出生命的光；羅馬書 12:2：心意更新，學習分辨。",
          "提摩太後書 1:7：剛強、仁愛、謹守；不必用恐懼作決定。",
          "請大家默想：今天最想帶走哪一句？心裏選一項就可以，不必公開表態。"],
         "安靜一下，用禱告回應。"),
    page("closing-prayer", "求祢幫我哋成為別人嘅祝福",
         "回應與禱告｜40–50 分鐘", 3, "light", "prayer",
         "提供修正後、可直接帶領的結束禱告。",
         ["先預留片刻安靜；邀請大家用自己舒適的姿勢禱告，也可以安靜聆聽。",
          "親愛的天父，謝謝祢召喚我們成為光明的兒女。在各種文化潮流中，求祢賜給我們智慧去分辨，勇氣去堅持合宜的選擇，也賜給我們愛心去尊重身邊的人。",
          "當我們面對同儕壓力或心裏不安，求祢幫助我們記得：祢所賜的是剛強、仁愛、謹守的心。讓我們用祢的愛與喜樂祝福朋友，成為帶來希望的人。",
          "禱告奉耶穌基督的名求，阿門。原稿「耶穌水晶」已修正為「耶穌基督」。"],
         "若你願意，也可以和身邊一位伙伴彼此代禱。"),
    page("pray-for-each-other", "為一位伙伴，送上禱告",
         "回應與禱告｜40–50 分鐘", 3, "hero dark", "pair-prayer",
         "用自願、低壓力的方式進行彼此代禱。",
         [         "兩人一組，自願分享一件想得到支持的事，例如同儕壓力或唔知點揀。",
          "約 1 分鐘彼此分享，再各用約 1 分鐘代禱；不想分享的人可安靜默禱。",
          "不必評論對方，也不必分享私密經歷；若有人需要進一步支持，請找導師。",
          "結束時提醒大家：我們不孤單，可以彼此支持。"],
         "把今天的祝福，化成一場有喜樂的光明派對。"),
    page("light-party", "光明派對，現在開始",
         "光明派對｜50–60 分鐘", 1, "hero light", "party",
         "清楚介紹光明禮包、點心和祝福卡活動。",
         ["邀請大家自由交流，領取果汁、零食包或寫有鼓勵經文的小禮物。",
          "螢光棒可作裝飾，但不要拆開或咬破；飲食前留意食物標示和過敏需要。",
          "拿一張卡，寫給一位朋友：一句真誠鼓勵，加上一個你願意做的支持行動。",
          "不需要暗房、火焰或恐怖元素，也能一起開心；確保走道和活動空間安全。"],
         "先寫下一束光，再把它帶出去。"),
    page("blessing-card", "寫一張卡，把光帶出去",
         "光明派對｜50–60 分鐘", 7.5, "light", "card",
         "在點心和交流中，完成可送出的具體祝福。",
         ["用約 2 分鐘寫卡，其餘時間自由交流、享用點心和互相鼓勵。",
          "卡片可以寫「多謝你一直陪住我」、「願你今天有平安」或其他真誠的說話。",
          "可以加一句經文或自己願意做的支持行動，例如陪朋友談談、一起溫習。",
          "尊重收卡人的信仰和意願，不以贈送零食或禮物作施壓；不強迫公開卡片內容。"],
         "聚會快結束了，把今天的一個選擇帶進生活。"),
    page("carry-the-light", "不只避開黑暗，更要活出光",
         "光明派對｜50–60 分鐘", .4, "hero dark", "closing",
         "用一個生活行動結束聚會。",
         ["感謝大家真實參與；提醒把卡片送給那位朋友。",
          "今天可以選擇一個行動：溫柔表達界線、向信任的人求助，或鼓勵一位朋友。",
          "祝福大家帶着平安與喜樂離開；若仍有問題或不安，聚會後可以找導師聊聊。"],
         "正常聚會在此結束；下一頁是供導師查閱的資料。"),
    page("reference-notes", "導師備查及內容簡介",
         "附錄｜不需投影", .1, "light", "sources",
         "保存歷史來源、經文出處及本次聚會的立場界線。",
         ["本頁是導師附錄，不需要在正常聚會逐項講解。",
          "歷史概述參考 HISTORY 的 History of Halloween；唔同民俗之間嘅具體關係仍有學者討論，唔會宣稱只有單一起源。",
          "經文採用使用者提供的和合本用語；三句帶走提醒頁標示為主題摘要，並非逐字引文。",
          "不把所有基督徒、教會或萬聖節參與者一概而論；按實際活動內容、信仰、良心及家庭規範分辨。"],
         "如需查閱來源，可點擊本頁連結。",
         links=[("HISTORY｜History of Halloween", HISTORY),
                ("Guizang PPT Skill｜設計與 HTML 模板", DESIGN)]),
]


class Scene:
    def __init__(self, p, number):
        self.p, self.number = p, number
        self.items = []
        self.dark = "dark" in p["theme"]
        self.fg = PAPER if self.dark else INK
        self.muted = "CFC0A9" if self.dark else "6A513D"
        self.line_color = "77604C" if self.dark else "BBA78D"
        self.highlight = "D8B78F" if self.dark else "804212"

    def text(self, value, x, y, w, h, size=24, serif=False, bold=False,
             color=None, align="left", link=None, spacing=1.18, verbatim=False):
        value = cantonese(value, verbatim=verbatim)
        self.items.append(dict(type="text", text=value, x=x, y=y, w=w, h=h,
                               size=size, serif=serif, bold=bold, color=color or self.fg,
                               align=align, link=link, spacing=spacing))

    def rect(self, x, y, w, h, color=None, stroke=None, ellipse=False):
        self.items.append(dict(type="ellipse" if ellipse else "rect", x=x, y=y,
                               w=w, h=h, color=color, stroke=stroke))

    def line(self, x1, y1, x2, y2, color=None, width=.8):
        self.items.append(dict(type="line", x=x1, y=y1, x2=x2, y2=y2,
                               color=color or self.line_color, width=width))

    def heading(self, kicker, title, size=36):
        self.text(kicker, .8, 1.08, 11.7, .4, 15, color=self.highlight, bold=True)
        self.text(title, .8, 1.72, 11.7, .82, size, serif=True, bold=True)

    def chrome(self):
        self.text("LIGHT PARTY  /  青少年團契", .8, .43, 7.8, .3, 11,
                  color=self.muted)
        self.text(f"{self.number:02d} / {len(PAGES):02d}", 11.4, .43, 1.12, .3,
                  11, color=self.muted, align="right")
        self.line(.8, .85, 12.53, .85)
        self.line(.8, 6.85, 12.53, 6.85)
        self.text(self.p["section"], .8, 7.03, 9.6, .27, 10,
                  color=self.muted)

    def halo(self, x=9.35, y=2.0, diameter=2.65):
        for grow in (0, .38, .76):
            self.rect(x-grow/2, y-grow/2, diameter+grow, diameter+grow,
                      stroke=self.line_color, ellipse=True)
        self.rect(x+.8, y+.8, diameter-1.6, diameter-1.6,
                  color=self.highlight, ellipse=True)
        center_x, center_y = x+diameter/2, y+diameter/2
        for angle in range(0, 360, 45):
            r = diameter*.32
            a = math.radians(angle)
            self.line(center_x+math.cos(a)*r, center_y+math.sin(a)*r,
                      center_x+math.cos(a)*r*1.22, center_y+math.sin(a)*r*1.22,
                      color=self.highlight, width=1.4)

    def columns(self, entries, y=3.15, w=3.55, gap=.54, size=22, h=2.3):
        for i, (label, title, body) in enumerate(entries):
            x = .8+i*(w+gap)
            self.line(x, y, x+w, y)
            self.text(label, x, y+.19, w, .38, 15, color=self.highlight, bold=True)
            self.text(title, x, y+.75, w, 1.02, size, serif=True, bold=True)
            self.text(body, x, y+1.85, w, h-1.0, 18, color=self.muted, spacing=1.35)


def make_scene(p, number):
    s = Scene(p, number)
    s.chrome()
    kind = p["kind"]
    if kind == "cover":
        s.text("一場關於文化、信仰與選擇的聚會", .8, 1.4, 8, .5, 18, color=s.highlight)
        s.text("選擇光明\n活出喜樂", .8, 2.15, 8.25, 2.55, 64, serif=True, bold=True)
        s.text("萬聖節文化 × 信仰分辨 × 同儕壓力", .8, 4.83, 8.1, .5, 23)
        s.text("60 分鐘  /  青少年聚會  /  光明派對", .8, 5.65, 8.1, .43, 16, color=s.muted)
        s.halo()
        s.text("LIGHT\nPARTY", 9.18, 5.38, 3.0, 1.0, 25, serif=True, align="center")
    elif kind == "agenda":
        s.heading("TODAY'S ROUTE", "一小時，一起走向光")
        rows = [("00–10", "破冰遊戲", "真假萬聖節大挑戰"),
                ("10–25", "專題講解", "歷史背景與三個信仰視角"),
                ("25–40", "小組討論", "同儕壓力、文化與選擇"),
                ("40–50", "回應與禱告", "經文總結、默想與彼此代禱"),
                ("50–60", "光明派對", "點心交流、光明禮包與祝福卡")]
        for i, (time, title, detail) in enumerate(rows):
            y = 2.91+i*.62
            s.line(.8, y, 12.53, y)
            s.text(time, .8, y+.13, 1.65, .4, 21, color=s.highlight, bold=True)
            s.text(title, 2.8, y+.13, 2.6, .4, 21, serif=True, bold=True)
            s.text(detail, 5.68, y+.13, 6.85, .4, 19, color=s.muted)
        s.text("現場 60 分鐘｜逐頁計畫 54 分鐘＋6 分鐘彈性", .8, 6.26, 11.73, .35, 14, color=s.muted)
    elif kind == "rules":
        s.heading("先鎖定答案，再揭曉", "真假萬聖節大挑戰")
        s.columns([("01｜分隊", "光明隊 × 晨光隊", "兩組正面隊名。\n一起商量，不取笑答錯的人。"),
                   ("02｜作答", "5 秒內，真或假", "讀完題目後口數倒數。\n用題目卡、手勢或口頭回答。"),
                   ("03｜計分", "答對，得 1 分", "先確認兩隊答案。\n下一頁才會揭曉。")], h=2.7)
        s.text("重點不是輸贏，而是一起看見：我們還有哪些不知道？",
               .8, 6.23, 11.73, .4, 18, color=s.muted)
    elif kind == "quiz":
        s.text(f"真假挑戰  /  QUESTION {p['quiz_number']}", .8, 1.28, 10, .4, 16, color=s.highlight)
        s.text(p["question"], .8, 2.21, 11.75, 1.75, 39, serif=True, bold=True, spacing=1.3)
        s.line(.8, 4.7, 12.53, 4.7)
        s.text("真 TRUE", .8, 5.02, 4.0, .75, 36, serif=True)
        s.text("還是", 5.72, 5.25, 1.6, .38, 18, color=s.muted, align="center")
        s.text("假 FALSE", 8.52, 5.02, 4.0, .75, 36, serif=True, align="right")
        s.text("5 秒商量 → 鎖定答案 → 翻頁揭曉", .8, 6.12, 11.73, .4, 17, color=s.muted)
    elif kind == "answer":
        s.text("答案揭曉", .8, 1.25, 3, .4, 16, color=s.highlight)
        s.text(p["answer"], .8, 2.13, 3.5, 2.65, 140, serif=True, color=s.highlight)
        s.text(p["heading"], 4.25, 1.98, 8.0, 1.6, 39, serif=True, bold=True, spacing=1.25)
        s.text(p["body"], 4.25, 3.98, 8.0, 1.73, 23, color=s.muted, spacing=1.5)
        s.text(p["source_label"], .8, 6.28, 11.73, .35, 13, color=s.muted)
    elif kind == "hook":
        s.text("唔只係「好玩」咁簡單。", .8, 1.48, 11.73, .5, 19, color=s.highlight)
        s.text("這個活動，\n在慶祝甚麼？", .8, 2.35, 11.73, 2.4, 58, serif=True, bold=True)
        s.text("先了解文化背景，再想清楚自己的選擇。", .8, 5.45, 11.73, .6, 25, color=s.muted)
    elif kind == "timeline":
        s.heading("節日會演變，不能只用一個起點解釋", "一個節日，幾層歷史")
        s.columns([("01｜古代背景", "薩溫節 Samhain", "收穫季結束、冬季開始。\n古人以篝火和民俗回應\n當時對亡靈的信念。"),
                   ("02｜教會節期", "諸聖節前夕", "11 月 1 日為諸聖節。\n前一晚 All Hallows' Eve，\n後來成為 Halloween。"),
                   ("03｜近代文化", "裝扮、糖果、派對", "民俗、移民與商業文化\n逐步交織，形成今天的\n各種節慶活動。")], y=3.0, h=3)
        s.text("歷史記述 ≠ 證實鬼魂存在｜參考：HISTORY，History of Halloween",
               .8, 6.37, 11.73, .3, 12, color=s.muted, link=HISTORY)
    elif kind == "distinction":
        s.heading("分辨活動，不標籤人", "別把三件事混為一談")
        s.columns([("文化由來", "歷史怎樣形成？", "古代背景不等於今天\n每位參加者的動機。"),
                   ("實際內容", "這次活動做甚麼？", "留意招魂、占卜、驚嚇，\n以及安全與身心需要。"),
                   ("信仰與良心", "我怎樣作選擇？", "不同教會立場不盡相同。\n可與家長、導師商量。")], h=2.7)
        s.text("本次聚會方向：不參與招魂、占卜與恐怖主題活動，改以光明派對回應。",
               .8, 6.16, 11.73, .5, 16, color=s.highlight)
    elif kind == "faith":
        s.text(p["principle"], .8, 1.2, 11.73, .4, 17, color=s.highlight, bold=True)
        s.text(p["title"], .8, 1.83, 11.73, .8, 34, serif=True, bold=True)
        quote_size = 25 if p["id"] == "faith-discern" else 31
        s.text(p["quote"], .8, 2.83, 11.73, 2.1, quote_size, serif=True, spacing=1.23, verbatim=True)
        s.text(p["reference"]+"｜和合本", .8, 4.98, 11.73, .35, 14, color=s.muted)
        for i, (label, body) in enumerate(p["applications"]):
            x = .8+i*6.05
            s.line(x, 5.53, x+5.65, 5.53)
            s.text(label, x, 5.73, 5.65, .36, 17, color=s.highlight, bold=True)
            s.text(body, x, 6.17, 5.65, .4, 21)
    elif kind == "filter":
        s.heading("問清楚，再決定", "一個邀請，三個分辨")
        s.columns([("看內容", "這活動做甚麼？", "是否涉及招魂、占卜，\n或令我不安的驚嚇？"),
                   ("看動機", "我為甚麼想去？", "是真心願意，\n還是怕被排斥？"),
                   ("找替代", "有別的方法嗎？", "可以保留友誼與喜樂，\n一起做合宜的活動。")], h=2.7)
        s.text("我們選擇光明派對：點心、鼓勵、祝福，而不是恐怖。",
               .8, 6.21, 11.73, .42, 19, color=s.highlight)
    elif kind == "group":
        s.heading("可以分享，也可以先聆聽", "真實說，也好好聽")
        s.text("4–6", .8, 3.14, 3.5, 1.7, 91, serif=True, color=s.highlight)
        s.text("人一組 × 一位導師", .8, 4.86, 3.6, .48, 21)
        for i, sentence in enumerate(["不嘲笑、不打斷，也不急着給答案。",
                                       "不用透露私密經歷；不想說也可以。",
                                       "讓每個人，都有被聆聽的空間。"]):
            s.line(4.72, 3.1+i*.93, 12.53, 3.1+i*.93)
            s.text(sentence, 4.72, 3.32+i*.93, 7.81, .55, 23)
        s.text("約 11 分鐘討論，再練習一句回應。", .8, 6.19, 11.73, .42, 18, color=s.muted)
    elif kind == "discussion":
        s.heading("沒有標準答案，想聽你的真實想法", "你會怎樣選擇？")
        cards = [("01｜同儕壓力 · 約 4 分鐘", "朋友邀請你扮鬼，\n你會怎樣回應？", "最擔心被取笑、被排斥，\n還是不知道怎樣說不？"),
                 ("02｜文化觀察 · 約 3 分鐘", "恐怖為何成為\n一種「娛樂」？", "商家怎樣包裝節日？\n哪些有趣，哪些讓你不安？"),
                 ("03｜信仰實踐 · 約 4 分鐘", "如果不扮鬼，\n可以一起做甚麼？", "想一個有意義、又好玩的\n替代活動。")]
        s.columns(cards, y=3.0, size=24, h=3)
        s.text("每人都有機會說；一起找可行的選擇，不急着下判斷。",
               .8, 6.36, 11.73, .32, 16, color=s.muted)
    elif kind == "reply":
        s.text("感謝邀請 → 表明界線 → 提出替代", .8, 1.36, 11.73, .44, 18, color=s.highlight)
        s.text("「多謝你邀請我！\n我唔參加扮鬼或招魂活動，\n不過我想同你一齊玩。\n不如來光明派對？」",
               .8, 2.12, 11.73, 2.95, 35, serif=True, spacing=1.3)
        s.text("兩人一組練習，再交換角色。可以改成自己的說話方式。",
               .8, 5.66, 11.73, .65, 21, color=s.muted)
    elif kind == "response":
        s.text("我們可以作出正面的選擇。", .8, 1.45, 11.73, .5, 19, color=s.highlight)
        s.text("不是少一點樂趣，\n是多一點光。", .8, 2.33, 11.73, 2.25, 55, serif=True, bold=True)
        s.text("慶祝生命與和平，讓朋友感到被愛。", .8, 5.4, 11.73, .65, 27, color=s.muted)
    elif kind == "summary":
        s.heading("經文主題摘要｜非逐字引文", "帶走三句提醒")
        s.columns([("約翰福音 8:12", "跟從耶穌", "帶出生命的光，\n讓人看見希望。"),
                   ("羅馬書 12:2", "更新、分辨", "不只跟隨潮流，\n學習察驗合宜的選擇。"),
                   ("提摩太後書 1:7", "剛強、仁愛、謹守", "不以恐懼作決定，\n也不用敵意回應朋友。")], size=23, h=2.7)
        s.text("今天，我最想實踐哪一句？", .8, 6.12, 11.73, .6, 28, serif=True, color=s.highlight)
    elif kind == "prayer":
        s.heading("可以一起禱告，也可以安靜聆聽", "求祢讓我們，成為祝福")
        prayer = ("親愛的天父，謝謝祢召喚我們成為光明的兒女。\n"
                  "求祢賜給我們智慧去分辨，勇氣去堅持合宜的選擇，\n"
                  "也賜給我們愛心去尊重身邊的人。\n"
                  "面對同儕壓力或心裏不安時，\n"
                  "讓我們記得祢所賜的，是剛強、仁愛、謹守的心。\n"
                  "讓我們用祢的愛與喜樂，成為朋友的祝福。\n"
                  "禱告奉耶穌基督的名求，阿門。")
        s.text(prayer, .8, 2.83, 11.73, 3.67, 23, serif=True, spacing=1.38)
    elif kind == "pair-prayer":
        s.text("自願分享，不必硬撐。", .8, 1.32, 11.73, .5, 20, color=s.highlight)
        s.text("你不孤單。", .8, 2.1, 11.73, 1.6, 76, serif=True, bold=True)
        s.columns([("約 1 分鐘", "分享一件需要", "同儕壓力、作選擇的困難，\n或一件想得到支持的事。"),
                   ("各約 1 分鐘", "為伙伴代禱", "簡單說出祝福，\n不用給建議或評論。"),
                   ("不想分享也可以", "安靜默禱", "若有需要，\n聚會後找導師談談。")], y=3.95, size=22, h=2)
    elif kind == "party":
        s.text("我們的替代選擇", .8, 1.34, 11.73, .4, 18, color=s.highlight)
        s.text("光明派對", .8, 2.13, 8.5, 1.5, 73, serif=True, bold=True)
        s.text("LIGHT PARTY", .8, 3.73, 8.4, .64, 30, serif=True, color=s.highlight)
        s.text("領取光明禮包  /  享用點心  /  寫一張祝福卡",
               .8, 4.89, 11.73, .62, 25)
        s.text("留意食物過敏；螢光棒不拆開、不咬破；保持走道暢通。",
               .8, 6.1, 11.73, .42, 17, color=s.muted)
        s.halo(9.49, 1.99, 2.1)
    elif kind == "card":
        s.heading("寫給一位，你想鼓勵的朋友", "寫一張卡，把光帶出去")
        s.rect(.8, 2.97, 7.36, 3.45, color=PAPER, stroke=s.line_color)
        s.text("親愛的 __________________：", 1.13, 3.35, 6.73, .5, 22, serif=True)
        s.text("多謝你一直陪住我。\n願你今天有平安，\n也記得你並不孤單。", 1.13, 4.12, 6.73, 1.8, 25, serif=True, spacing=1.35)
        s.text("你的朋友：__________________", 1.13, 5.99, 6.73, .3, 17, color=s.muted)
        s.text("一張卡，三個元素", 8.7, 3.21, 3.83, .6, 25, serif=True, bold=True)
        s.text("一句真誠鼓勵\n一項支持行動\n一位想祝福的朋友", 8.7, 4.25, 3.83, 1.8, 23, spacing=1.65)
        s.text("約 2 分鐘寫卡，其餘時間自由交流。", 8.7, 6.09, 3.83, .54, 15, color=s.muted)
    elif kind == "closing":
        s.text("讓信仰，成為一個今天就能做的行動。", .8, 1.37, 11.73, .5, 19, color=s.highlight)
        s.text("不只避開黑暗，\n更要活出光。", .8, 2.24, 11.73, 2.2, 59, serif=True, bold=True)
        s.text("溫柔表達界線  /  鼓勵一位朋友  /  把祝福帶出去",
               .8, 5.3, 11.73, .64, 24, color=s.muted)
        s.text("願你帶着平安與喜樂，成為身邊人的祝福。", .8, 6.21, 11.73, .4, 19, color=s.highlight)
    elif kind == "sources":
        s.heading("導師附錄｜正常聚會不需逐項講解", "參考資料與內容說明")
        s.text("歷史與設計來源", .8, 2.9, 11.73, .43, 23, serif=True, bold=True)
        for i, (label, url) in enumerate(p["links"]):
            y = 3.47+i*.72
            s.text(label+" ↗", .8, y, 11.73, .35, 17, color=s.highlight, link=url)
            s.text(url, .8, y+.36, 11.73, .28, 11, color=s.muted, link=url)
        s.text("經文：使用者提供的和合本用語｜約 8:12、羅 12:2、提後 1:7",
               .8, 5.12, 11.73, .45, 17)
        s.text("內容說明：薩溫節不是冬至前夕；民俗不是單一起源。\n"
               "不同教會立場不盡相同；本聚會以光明派對作正面回應。\n"
               "逐頁計畫共 54 分鐘，現場 60 分鐘；附錄只作導師備查。",
               .8, 5.66, 11.73, 1.05, 15, color=s.muted, spacing=1.38)
    else:
        raise ValueError(f"Unknown slide kind: {kind}")
    return s


def rgb(value):
    return RGBColor.from_string(value)


def add_font_run(paragraph, text, item):
    run = paragraph.add_run()
    run.text = text
    run.font.name = TITLE_FONT if item["serif"] else BODY_FONT
    run.font.size = Pt(item["size"])
    run.font.bold = item["bold"]
    run.font.color.rgb = rgb(item["color"])
    props = run._r.get_or_add_rPr()
    ea = OxmlElement("a:ea")
    ea.set("typeface", run.font.name)
    props.append(ea)
    props.set("lang", "zh-HK")
    if item.get("link"):
        run.hyperlink.address = item["link"]


def export_pptx(scenes):
    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(WIDTH), Inches(HEIGHT)
    prs.core_properties.title = "選擇光明，活出喜樂｜60 分鐘青少年聚會"
    prs.core_properties.subject = "萬聖節文化、信仰分辨、同儕壓力與光明派對"
    prs.core_properties.author = "聚會導師"
    prs.core_properties.keywords = "光明派對,青少年,團契,萬聖節,信仰分辨"
    for scene in scenes:
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        slide.background.fill.solid()
        slide.background.fill.fore_color.rgb = rgb(INK if scene.dark else PAPER)
        for item in scene.items:
            if item["type"] == "text":
                shape = slide.shapes.add_textbox(Inches(item["x"]), Inches(item["y"]),
                                                Inches(item["w"]), Inches(item["h"]))
                shape.name = f"Text: {item['text'][:32]}"
                tf = shape.text_frame
                tf.clear()
                tf.word_wrap = True
                tf.margin_left = tf.margin_right = 0
                tf.margin_top = tf.margin_bottom = 0
                tf.vertical_anchor = MSO_ANCHOR.TOP
                for n, text in enumerate(item["text"].split("\n")):
                    paragraph = tf.paragraphs[0] if n == 0 else tf.add_paragraph()
                    paragraph.alignment = {"left": PP_ALIGN.LEFT, "center": PP_ALIGN.CENTER,
                                           "right": PP_ALIGN.RIGHT}[item["align"]]
                    paragraph.line_spacing = item["spacing"]
                    paragraph.space_before = paragraph.space_after = Pt(0)
                    add_font_run(paragraph, text, item)
            elif item["type"] == "line":
                shape = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,
                                                   Inches(item["x"]), Inches(item["y"]),
                                                   Inches(item["x2"]), Inches(item["y2"]))
                shape.line.color.rgb = rgb(item["color"])
                shape.line.width = Pt(item["width"])
            else:
                shape_type = MSO_AUTO_SHAPE_TYPE.OVAL if item["type"] == "ellipse" else MSO_AUTO_SHAPE_TYPE.RECTANGLE
                shape = slide.shapes.add_shape(shape_type, Inches(item["x"]), Inches(item["y"]),
                                              Inches(item["w"]), Inches(item["h"]))
                if item["color"]:
                    shape.fill.solid()
                    shape.fill.fore_color.rgb = rgb(item["color"])
                else:
                    shape.fill.background()
                if item["stroke"]:
                    shape.line.color.rgb = rgb(item["stroke"])
                    shape.line.width = Pt(.8)
                else:
                    shape.line.fill.background()
        p = scene.p
        notes = [p["title"], p["section"], f"呢頁建議：{p['minutes']:g} 分鐘",
                 "呢頁重點："+p["purpose"], "", "導師可以咁講："]
        notes.extend(f"{i+1}. {point}" for i, point in enumerate(p["talk"]))
        notes.extend(["", "轉去下一頁："+p["transition"],
                      "時間提示：現場共 60 分鐘；每頁安排共 54 分鐘，留返 6 分鐘彈性。"])
        if p["kind"] in {"timeline", "answer", "sources"}:
            notes.extend(["", "歷史概述參考："+HISTORY])
        slide.notes_slide.notes_text_frame.text = "\n".join(notes)
    path = OUT / "light-party.pptx"
    prs.save(path)
    return path


def percent(value, base):
    return f"{value/base*100:.6f}%"


def css_color(scene, value):
    tokens = {scene.fg: "--text-primary", scene.muted: "--text-secondary",
              scene.line_color: "--line-strong", scene.highlight: "--accent-ink",
              PAPER: "--paper", INK: "--ink", ACCENT: "--accent"}
    return f"var({tokens[value]})"


def html_item(scene, item):
    typ = item["type"]
    x, y = item["x"], item["y"]
    styles = ["position:absolute", f"left:{percent(x,WIDTH)}", f"top:{percent(y,HEIGHT)}"]
    if typ == "line":
        dx, dy = item["x2"]-x, item["y2"]-y
        styles.extend([f"width:calc({math.hypot(dx,dy)/WIDTH*100:.6f} * var(--u))",
                       f"border-top:calc({item['width']/9.6:.6f} * var(--u)) solid {css_color(scene,item['color'])}",
                       f"transform:rotate({math.degrees(math.atan2(dy,dx)):.6f}deg)",
                       "transform-origin:top left"])
        return '<div aria-hidden="true" style="'+";".join(styles)+'"></div>'
    styles.extend([f"width:{percent(item['w'],WIDTH)}", f"height:{percent(item['h'],HEIGHT)}"])
    if typ == "text":
        font = "var(--serif-zh)" if item["serif"] else "var(--sans-zh)"
        styles.extend([f"font-family:{font}", f"font-size:calc({item['size']/9.6:.6f} * var(--u))",
                       f"font-weight:{700 if item['bold'] else 400}",
                       f"line-height:{item['spacing']}", f"color:{css_color(scene,item['color'])}",
                       f"text-align:{item['align']}", "white-space:pre-wrap",
                       "overflow-wrap:normal", "word-break:normal"])
        text = html.escape(item["text"])
        if item["link"]:
            text = f'<a href="{html.escape(item["link"],quote=True)}" target="_blank" rel="noopener noreferrer" style="color:inherit;text-decoration:none">{text}</a>'
        return '<div style="'+";".join(styles)+'">'+text+"</div>"
    if item["color"]:
        styles.append(f"background:{css_color(scene,item['color'])}")
    if item["stroke"]:
        styles.append(f"border:calc(.083333 * var(--u)) solid {css_color(scene,item['stroke'])}")
    if typ == "ellipse":
        styles.append("border-radius:50%")
    return '<div aria-hidden="true" style="'+";".join(styles)+'"></div>'


def export_html(scenes):
    template = (SOURCE / "template.html").read_text(encoding="utf-8")
    template = template.replace('lang="zh-CN"', 'lang="zh-HK"').replace(
        'data-theme="ink-classic"', 'data-theme="kraft-paper"', 1)
    template = template.replace("[必填] 替换为 PPT 标题 · Deck Title", "選擇光明，活出喜樂｜60 分鐘青少年聚會")
    template = re.sub(r"^\s*<link\b[^>]*>\s*$", "", template, flags=re.MULTILINE)
    frame_style = ("position:absolute;--u:min(1vw,1.777778vh);"
                   "width:calc(100 * var(--u));height:calc(56.25 * var(--u));"
                   "left:50%;top:50%;transform:translate(-50%,-50%);padding:0")
    slides = []
    for scene in scenes:
        slides.append(f'<section class="slide {scene.p["theme"]}" data-slide-id="{scene.p["id"]}" aria-label="{html.escape(scene.p["title"],quote=True)}">\n'
                      f'<div class="frame" style="{frame_style}">\n'
                      + "\n".join(html_item(scene, item) for item in scene.items)
                      + "\n</div>\n</section>")
    template = template.replace("<!-- SLIDES_HERE -->", "\n".join(slides))
    notes = [{k: p[k] for k in ("id", "title", "section", "minutes", "purpose", "talk", "transition")}
             for p in PAGES]
    assert abs(sum(n["minutes"] for n in notes)-54) < 1e-8
    template = re.sub(r"const SPEAKER_NOTES = \[[\s\S]*?\];\s*window.__SPEAKER_NOTES__ = SPEAKER_NOTES;",
                      lambda _: "const SPEAKER_NOTES = "+json.dumps(notes, ensure_ascii=False, indent=2)
                      +";\nwindow.__SPEAKER_NOTES__ = SPEAKER_NOTES;", template, count=1)
    template = template.replace(
        '  <button id="ppt-presenter-btn" type="button"><span class="ppt-key">P</span>演讲模式</button>',
        '  <button id="ppt-presenter-btn" type="button"><span class="ppt-key">P</span>演讲模式</button>\n'
        '  <a id="ppt-download-btn" class="ppt-download-btn" href="./light-party.pptx" '
        'download="light-party.pptx" aria-label="下載 PowerPoint 簡報">'
        '<span class="ppt-key" aria-hidden="true">↓</span>下載 PowerPoint</a>')
    local_fonts = """
<style>
:root {
  --font-serif-zh:"PMingLiU","Songti TC","Noto Serif TC",serif;
  --font-sans:"Microsoft JhengHei","PingFang TC","Noto Sans TC",sans-serif;
  --font-display:"Georgia","Times New Roman",serif;
  --font-serif:"Georgia","Times New Roman",serif;
  --font-mono:"Consolas","Microsoft JhengHei",monospace;
}
/* Modified 2026-10-31: fixed-ratio scenes, local fonts and offline animation. */
.slide.hero.dark::before { background:rgba(var(--ink-rgb),.78) }
.slide.hero.light::before { background:rgba(var(--paper-rgb),.82) }
.slide.hero::after { background:none }
#hint { font-family:var(--sans-zh);font-size:12px;letter-spacing:0;bottom:.6vh;opacity:.72 }
#hint a.ppt-download-btn { display:inline-flex;align-items:center;gap:.45em;color:inherit;white-space:nowrap;text-decoration:none }
#hint a.ppt-download-btn:hover,#hint a.ppt-download-btn:focus-visible { opacity:1;text-decoration:underline;text-underline-offset:.35em }
#hint a.ppt-download-btn:focus-visible { outline:2px solid currentColor;outline-offset:3px }
#nav { max-width:80vw;bottom:.6vh }
@media print {
  html,body { overflow:visible;height:auto;background:var(--paper) }
  #deck { position:static;display:block;width:auto!important;height:auto;transform:none!important }
  #deck > .slide { width:100vw;height:56.25vw;page-break-after:always;background:var(--paper) }
  #deck > .slide.dark { background:var(--ink) }
  .slide .frame { --u:1vw!important }
  canvas.bg,#hint,#nav,#overview { display:none!important }
}
</style>
"""
    template = template.replace("</head>", local_fonts+"</head>", 1)
    template = re.sub(r'<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>\s*'
                      r'<script>lucide.createIcons\(\);</script>', "", template)
    motion = base64.b64encode((SOURCE / "motion.min.js").read_bytes()).decode("ascii")
    template = template.replace("import('./assets/motion.min.js')",
                                "import('data:text/javascript;base64,"+motion+"')")
    license_text = (SOURCE / "LICENSE").read_text(encoding="utf-8")
    motion_license = (SOURCE / "MOTION-LICENSE").read_text(encoding="utf-8")
    notice = ("\n<!-- Modified on 2026-10-31 from Guizang PPT Skill, "+DESIGN+".\n"
              "The template-derived software is licensed under AGPL-3.0.\n"
              "Corresponding source is this HTML and the source bundle delivered alongside it.\n"
              "This software notice does not relicense the user's original presentation content.\n"
              +license_text.replace("--", "- -")+"\nMotion library notice:\n"
              +motion_license.replace("--", "- -")+"\n-->\n")
    template = template.replace("<!DOCTYPE html>", "<!DOCTYPE html>"+notice, 1)
    template = cantonese(template)
    path = OUT / "light-party.html"
    path.write_text(template, encoding="utf-8")
    return path


def package_source(pptx, deck):
    bundle = OUT / "light-party-source.zip"
    with zipfile.ZipFile(bundle, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.write(pptx, pptx.name)
        z.write(deck, deck.name)
        z.write(__file__, "source/build_deck.py")
        for name in ("template.html", "motion.min.js", "LICENSE", "MOTION-LICENSE",
                     "themes.md", "layouts.md", "checklist.md", "validate-presenter-mode.mjs"):
            z.write(SOURCE/name, "source/guizang-source/"+name)
        z.writestr("授權與使用說明.txt",
                   "選擇光明，活出喜樂｜60 分鐘青少年聚會\n\n"
                   "PPTX：文字與基本圖形可編輯；導師講述在逐頁備註中。\n"
                   "字型：標題 PMingLiU，內文 Microsoft JhengHei；其他裝置會使用替代字型。\n"
                   "HTML：可直接雙擊開啟，毋須上網；方向鍵翻頁、Esc 總覽、P 講者模式。\n"
                   "演講者模式會開啟觀眾視窗；若瀏覽器攔截彈窗，請允許並重新開啟。\n"
                   "計時需手動開始；預設不會自動翻頁。54 分鐘逐頁計畫＋6 分鐘現場彈性。\n"
                   "第 27 頁是導師附錄，正常聚會可停在第 26 頁。\n\n"
                   "HTML 改編自 "+DESIGN+"，程式碼採 AGPL-3.0；授權全文見 source/guizang-source/LICENSE。\n"
                   "Motion 採 MIT；全文見 source/guizang-source/MOTION-LICENSE。\n"
                   "上述程式碼授權唔會改變使用者原有講章同內容嘅權利。\n"
                   "修改日期：2026-10-31；修改包括聚會內容、固定比例版面、離線字型同內嵌動畫。\n"
                   "已附上對應原始碼。要重新建置，請將 source 資料夾解壓縮到可寫入嘅位置，安裝 python-pptx 同 opencc-python-reimplemented，再執行 build_deck.py。\n")
    return bundle


def main():
    OUT.mkdir(exist_ok=True)
    assert len({p["id"] for p in PAGES}) == len(PAGES)
    assert sum(p["minutes"] for p in PAGES) == 54
    scenes = [make_scene(p, i+1) for i, p in enumerate(PAGES)]
    for scene in scenes:
        for item in scene.items:
            if item["type"] != "line":
                assert item["x"] >= 0 and item["y"] >= 0
                assert item["x"]+item["w"] <= WIDTH+.01, item
                assert item["y"]+item["h"] <= HEIGHT+.01, item
    pptx = export_pptx(scenes)
    deck = export_html(scenes)
    bundle = package_source(pptx, deck)
    (ROOT/"scenes.json").write_text(
        json.dumps([{"id": s.p["id"], "items": s.items} for s in scenes],
                   ensure_ascii=False, indent=2), encoding="utf-8")
    for path in (pptx, deck, bundle):
        print(f"{path.name}: {path.stat().st_size:,} bytes")
    print(f"{len(PAGES)} slides; {sum(p['minutes'] for p in PAGES):g} planned minutes; editable text and shapes.")


if __name__ == "__main__":
    main()
